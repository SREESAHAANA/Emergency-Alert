const express = require('express');
const nodemailer = require('nodemailer');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// List of emails and their coordinates
const recipients = [
    { email: 'snegakuttymusic@gmail.com', latitude: 37.7749, longitude: -122.4194 }, 
    { email: 'snegaagensk@gmail.com', latitude: 34.0522, longitude: -118.2437 }  
];

// Nodemailer transporter setup
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'snegak.cse2022@citchennai.net',
        pass: 'lpjl camh qxcy qhjj'
    }
});

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Haversine formula to calculate distance between two coordinates
function getDistance(lat1, lon1, lat2, lon2) {
    const toRad = (x) => x * Math.PI / 180;
    const R = 6371; // Radius of the Earth in km
    const dLat = toRad(lat2 - lat1);
    const dLon = toRad(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

// Endpoint to send email
app.post('/send-alert', (req, res) => {
    const { latitude, longitude } = req.body;
    let nearestRecipient = recipients[0];
    let minDistance = getDistance(latitude, longitude, nearestRecipient.latitude, nearestRecipient.longitude);

    recipients.forEach(recipient => {
        const distance = getDistance(latitude, longitude, recipient.latitude, recipient.longitude);
        if (distance < minDistance) {
            nearestRecipient = recipient;
            minDistance = distance;
        }
    });

    const mailOptions = {
        from: 'snegak.cse2022@citchennai.net',
        to: nearestRecipient.email,
        subject: 'Emergency Alert: Car Accident',
        html: `
            <p>I met with a car accident, please save me.</p>
            <p>Click <a href="https://www.google.com/maps?q=${latitude},${longitude}">here</a> to view my live location.</p>
            <p>Here are the marks of the car and my current location coordinates:</p>
            <ul>
                <li>Latitude: ${latitude}</li>
                <li>Longitude: ${longitude}</li>
            </ul>
        `
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Error sending email:', error);
            res.status(500).json({ message: 'Error sending email' });
        } else {
            console.log('Email sent:', info.response);
            res.status(200).json({ message: 'Emergency alert sent successfully!' });
        }
    });
});

// Handle unsupported HTTP methods
app.use((req, res) => {
    res.status(405).send('Method Not Allowed');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
